package Games;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class GamesUpdateServlet
 */
@WebServlet("/GamesUpdateServlet")
@MultipartConfig
public class GamesUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GamesUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				PrintWriter out = response.getWriter();
				response.setContentType("text/html");
				
				int id= Integer.parseInt(request.getParameter("id"));
		        String name = request.getParameter("name");
		        String category = request.getParameter("category");
		        String description = request.getParameter("description");
		        String date = request.getParameter("date");
		        int rating= Integer.parseInt(request.getParameter("rating"));
		      

		        boolean isSuccess;
		        
		        // Define the save directory for images
		        String appPath = request.getServletContext().getRealPath("");
		        String savePath = appPath + File.separator + "images";

		        // Create the save directory if it does not exist
		        File fileSaveDir = new File(savePath);
		        if (!fileSaveDir.exists()) {
		            fileSaveDir.mkdir();
		        }

		        // Initialize imageUrl to empty string
		        String imageUrl = "";

		        // Iterate through the parts of the multipart request
		        for (Part part : request.getParts()) {
		            // Extract the file name from the part
		            String fileName = extractFileName(part);
		            // If the file name is not empty, save the file to the images directory
		            if (!fileName.equals("")) {
		                part.write(savePath + File.separator + fileName);
		                imageUrl = "images/" + fileName; // Set the imageUrl to the path where the file is saved
		            }
		        }

		        isSuccess = GameDBUtill.updateGame(id, name, category, description, date, rating, imageUrl);
		        
		        if (isSuccess) {
		        	// eventsList is the list of events fetched from the database
		        	List<Game> fedDetails = GameDBUtill.getAllGames();
		            request.setAttribute("fedDetails", fedDetails);
		            
		            RequestDispatcher dis = request.getRequestDispatcher("admindashboard.jsp");
		            dis.forward(request, response);
		        } else {
		            // Handle insertion failure
		            response.sendRedirect("error.jsp");
		        }
		    }
		    
		    private String extractFileName(Part part) {
		        String contentDisp = part.getHeader("content-disposition");
		        String[] items = contentDisp.split(";");
		        for (String s : items) {
		            if (s.trim().startsWith("filename")) {
		                return s.substring(s.indexOf("=") + 2, s.length() - 1);
		            }
		        }
		        return "";

	}

}
