package Games;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class GameDBUtill {
	
	private static Connection con = null;
	private static Statement stmt = null;
	private static ResultSet rs = null;
	public static boolean isSucess;
	public static int id;
	
	public static boolean insertGame(String name, String category, String description, String date, int rating, String img) {
			
			boolean isInsert = false;
			
			try {
				con = DBConnect.getConnection();
				stmt = con.createStatement();
				
				String query = "insert into `games` values(0, '"+name+"', '"+category+"', '"+description+"', '"+date+"', '"+rating+"', '"+img+"')";
				int val = stmt.executeUpdate(query); //this will return the integer value
				
				if (val > 0) {
					isInsert = true;
				}
				else {
					isInsert = false;
				}
				
			}
			
			catch(Exception e) {
				e.printStackTrace();
			}
			
			return isInsert;
		}
	
	
	public static List<Game> getAllGames() {
		
		ArrayList<Game> lev = new ArrayList<>();
		
		
		try {
			con = DBConnect.getConnection();
			stmt = con.createStatement();
			String query = "select * from `games`";
			rs = stmt.executeQuery(query);
			
			while (rs.next()) {
				id = rs.getInt(1);
				String name = rs.getString(2);
				String category = rs.getString(3);
				String description = rs.getString(4);
				String date = rs.getString(5);
				int rating = rs.getInt(6);
				String img = rs.getString(7);
			
				
				Game c1 = new Game(id, name, category, description, date, rating, img);
				
				lev.add(c1);
			}
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		
		return lev;
	}
	
	
	public static boolean updateGame(int gid, String name, String category, String description, String date, int rating, String img) {
		
		try {
			con = DBConnect.getConnection();
			stmt = con.createStatement();
			String query = "update `games` set name='"+name+"', category='"+category+"', description='"+description+"', date='"+date+"', rating='"+rating+"', img='"+img+"'" 
					+ "where id='"+gid+"'";
			int rs = stmt.executeUpdate(query);
			
			if (rs > 0) {
				isSucess = true;
			}
			
			else {
				isSucess = false;
			}
			
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return isSucess;
	}
	
	
	
	public static boolean deleteGame(int id) {

		try {
			con = DBConnect.getConnection();
			stmt = con.createStatement();
			String query = "delete from `games` where id = '"+id+"'";
			int rs = stmt.executeUpdate(query);
			
			if (rs > 0) {
				isSucess = true;
			}
			
			else {
				isSucess = false;
			}
			
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return isSucess;
	}

}
